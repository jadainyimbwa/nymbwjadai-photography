/*
  EDIT THIS FILE to change your name, series titles and photos.
  - Put your photos in the images/ folder (e.g. images/portraits/01.jpg)
  - List each file path in the "images" array of its series.
  - The page for each series is a separate .html file (see "page").
*/
window.SITE = {
  name: "Jadai Nyimbwa",
  series: [
    {
      num: "01", title: "Portraits", page: "index.html",
      images: [
        "images/portraits/01.svg", "images/portraits/02.svg", "images/portraits/03.svg",
        "images/portraits/04.svg", "images/portraits/05.svg", "images/portraits/06.svg"
      ]
    },
    {
      num: "02", title: "Belgrade", page: "series-02.html",
      images: [
        "images/belgrade/01.svg", "images/belgrade/02.svg", "images/belgrade/03.svg",
        "images/belgrade/04.svg", "images/belgrade/05.svg", "images/belgrade/06.svg"
      ]
    },
    {
      num: "03", title: "Running", page: "series-03.html",
      images: [
        "images/running/01.svg", "images/running/02.svg", "images/running/03.svg",
        "images/running/04.svg", "images/running/05.svg", "images/running/06.svg"
      ]
    },
    {
      num: "04", title: "Quiet Rooms", page: "series-04.html",
      images: [
        "images/rooms/01.svg", "images/rooms/02.svg", "images/rooms/03.svg",
        "images/rooms/04.svg", "images/rooms/05.svg", "images/rooms/06.svg"
      ]
    }
  ]
};
